package �����Ѱ���;
import java.util.Scanner;
public class reverse1test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String tostring;
		Scanner scan = new Scanner(System.in);
reverse1 myreverse1= new reverse1();
System.out.print("���ڿ��� �Է��Ͻÿ�: ");
tostring = scan.nextLine();
myreverse1.reverse(tostring);

	}

}
