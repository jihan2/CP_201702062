package �����Ѱ���;

public class fsfsdfsdgsd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int a = 1; a < 6; a++) {
			for (int b = 5; b > a; b--) {
				System.out.print(" ");
			}
			for (int c = 0; c < a; c++) {
				System.out.print("*");
			}
			for (int d = 1; d < a; d++) {
				System.out.print("*");
			}
			System.out.println();
		}
		for(int a = 1; a<5; a++) {
			for (int b = 0; b<a;b++) {
				System.out.print(" ");
			}
			for(int c=5; c>a; c--) {
				System.out.print("*");
			}for(int d=4; d>a; d--) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
}
